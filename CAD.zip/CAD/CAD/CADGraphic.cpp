#include "StdAfx.h"
#include "CADGraphic.h"

#include "CADDoc.h"
#include "Afxwin.h"


IMPLEMENT_SERIAL(CCADGraphic, CObject, 1)

CCADGraphic::CCADGraphic(void)
{
    m_uidrawType = 0;         // ��    
	m_uilineWidth = 1;        // �߿�Ϊ1
	m_ilineStyle = PS_SOLID;  // ʵ��
	m_graClr = RGB(0, 0, 0);  // ��ɫ
	m_ptFrom = 0;             // (0, 0)
	m_ptTo = 0;               // (0, 0)

}

CCADGraphic::CCADGraphic(DRAW_TYPE uidrawType, 
	                     LINE_STYLE ilineStyle, 
						 LINE_WIDTH uilineWidth, 
	                     COLORREF graClr, 
						 CPoint ptFrom, 
						 CPoint ptTo)
{
	this->m_uidrawType = uidrawType;
	this->m_ilineStyle = ilineStyle;
	this->m_uilineWidth = uilineWidth;
	this->m_graClr = graClr;
	this->m_ptFrom = ptFrom;
	this->m_ptTo = ptTo;
}

CCADGraphic::~CCADGraphic(void)
{
}

void CCADGraphic::Serialize(CArchive &ar)
{

	if (ar.IsStoring()) // �洢
	{
		ar << m_uidrawType << m_ilineStyle << m_uilineWidth << m_graClr
		<< m_ptFrom << m_ptTo;
		
		/*list<CPoint>::iterator iPt;
		for(iPt = m_ptsCurve.begin(); iPt != m_ptsCurve.end(); iPt++)
			ar << *iPt;*/
	}
	else                // ��ȡ
	{
		ar >> m_uidrawType >> m_ilineStyle >> m_uilineWidth >> m_graClr
		>> m_ptFrom >> m_ptTo;

		/*list<CPoint>::iterator iPt;
		for(iPt = m_ptsCurve.begin(); iPt != m_ptsCurve.end(); iPt++)
			ar >> *iPt;*/
	}
}

void CCADGraphic::Draw(CDC *pDC)
{
    CPen pen(m_ilineStyle, m_uilineWidth, m_graClr);
	pDC->SelectObject(pen);
	CBrush *pBrush = CBrush::FromHandle((HBRUSH)GetStockObject(NULL_BRUSH)); // ����͸����ˢ
	CBrush *pOldBrush = pDC->SelectObject(pBrush); // ����ǰ��ˢѡ���豸�����������ؾɻ�ˢ
	
	CPoint circleCenter;                           // Բ��
	circleCenter.x = (float(m_ptFrom.x + m_ptTo.x)) / 2;
	circleCenter.y = (float(m_ptFrom.y + m_ptTo.y)) / 2;
	int m_iRadius = sqrt(double(m_ptTo.y - m_ptFrom.y) * (m_ptTo.y - m_ptFrom.y)   // �뾶
							+ (m_ptTo.x - m_ptFrom.x) * (m_ptTo.x - m_ptFrom.x)) / 2;

	list<CPoint>::iterator iPt;
	switch(m_uidrawType)
	{
	case DOT:
		pDC->SetPixel(m_ptTo, m_graClr);           // ���� .
		break;
	case LINE:                                     // ֱ�� --->
		pDC->MoveTo(m_ptFrom);
		pDC->LineTo(m_ptTo);
		break;
	case RECTANGLE:                                // ���� ��
		pDC->Rectangle(CRect(m_ptFrom, m_ptTo));
		break;
	case ELLIPSE:                                  // ��Բ 0
		pDC->Ellipse(CRect(m_ptFrom, m_ptTo));
		break;
	case CIRCLE:                                   // ��Բ O
		pDC->Ellipse(circleCenter.x - m_iRadius, circleCenter.y - m_iRadius,
				     circleCenter.x + m_iRadius, circleCenter.y + m_iRadius);
		break;
	case TRIANGLE:
		pDC->MoveTo(m_ptFrom);            
		pDC->LineTo(m_ptTo.x, m_ptFrom.y); // --->
		
		pDC->MoveTo(m_ptFrom);             //.
		pDC->LineTo(m_ptTo);               // .
		                                   //  .
		pDC->MoveTo(m_ptTo.x, m_ptFrom.y); //   |
		pDC->LineTo(m_ptTo);               //   |
		                                   //   V
		break;
	case ARC:
		pDC->Arc(CRect(m_ptFrom, m_ptTo), m_ptFrom, m_ptTo);  // ���� C
		break;
	case PIE:
		pDC->Pie(CRect(m_ptFrom, m_ptTo), m_ptFrom, m_ptTo);  // ���� D
	case RRECT:
		pDC->RoundRect(m_ptFrom.x, m_ptFrom.y,                // ��
			           m_ptTo.x, m_ptTo.y,                    //.-.
			           (m_ptTo.x - m_ptFrom.x) / 2,           //| |
					   (m_ptTo.y - m_ptFrom.y) / 2);          //._.
		break;
	case CURVE:

		for(iPt = m_ptsCurve.begin(); iPt != m_ptsCurve.end();)
		{
			pDC->MoveTo(*iPt);
			iPt++;
			if(iPt != m_ptsCurve.end())
				pDC->LineTo(*iPt);
		}
		break;
	default:
		break;
	}
	pDC->SelectObject(pOldBrush);                             // ������ɺ󽫾ɻ�ˢѡ���豸������
}
