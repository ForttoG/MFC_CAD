
// CADView.cpp : CCADView ���ʵ��
//

#include "stdafx.h"
// SHARED_HANDLERS ������ʵ��Ԥ��������ͼ������ɸѡ�������
// ATL ��Ŀ�н��ж��壬�����������Ŀ�����ĵ����롣
#ifndef SHARED_HANDLERS
#include "CAD.h"
#endif

#include "CADDoc.h"
#include "CADView.h"
#include "MainFrm.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#endif

#pragma warning (disable: 4244)  // disable float to LONG warning 

//extern CCADApp theApp;

// CCADView

IMPLEMENT_DYNCREATE(CCADView, CScrollView)

// ��Ϣӳ��
BEGIN_MESSAGE_MAP(CCADView, CScrollView)
	
	// ��׼��ӡ����
	ON_COMMAND(ID_FILE_PRINT, &CScrollView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, &CScrollView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, &CCADView::OnFilePrintPreview)
	// ����Ҽ������˵�
	ON_WM_CONTEXTMENU()
	ON_WM_RBUTTONUP()
	// ��ͼ������
	ON_COMMAND(IDR_CLR, &CCADView::OnIdrClr)
	ON_COMMAND(IDR_SET, &CCADView::OnIdrSet)
	ON_COMMAND(IDR_DOT, &CCADView::OnIdrDot)
	ON_COMMAND(IDR_LINE, &CCADView::OnIdrLine)
	ON_COMMAND(IDR_RECT, &CCADView::OnIdrRect)
	ON_COMMAND(IDR_ELLIPSE, &CCADView::OnIdrEllipse)
	ON_COMMAND(IDR_CIRCLE, &CCADView::OnIdrCircle)
	ON_COMMAND(IDR_TRIANGLE, &CCADView::OnIdrTriangle)
	// ������
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_MOUSEMOVE()

	ON_COMMAND(IDR_ARC, &CCADView::OnIdrArc)
	ON_COMMAND(IDR_PIE, &CCADView::OnIdrPie)
	ON_COMMAND(IDR_ROUNDRECT, &CCADView::OnIdrRoundrect)
	ON_COMMAND(IDR_CURVE, &CCADView::OnIdrCurve)
	ON_WM_PAINT()
END_MESSAGE_MAP()

// CCADView ����/����

CCADView::CCADView()
	: m_uidrawType(0)       // ��
	, m_uilineWidth(1)      // �߿�1
	, m_ilineStyle(PS_SOLID)// ʵ��
	, m_graClr(RGB(0, 0, 0))// ��ɫ
	, m_ptFrom(0)           // (0, 0)
	, m_ptTo(0)             // (0, 0)
	, m_bCapEn(true)        // ��׽
	, m_bTracking(false)    // δ׷��
	, m_bDrawing(false)     // δ��ʼ��ͼ
{

}

CCADView::~CCADView()
{
}

BOOL CCADView::PreCreateWindow(CREATESTRUCT& cs)
{
	//  CREATESTRUCT cs ���޸Ĵ��������ʽ

	return CScrollView::PreCreateWindow(cs);
}

// CCADView ����

void CCADView::OnDraw(CDC* pDC)
{
	CCADDoc* pDoc = GetDocument();       // ��ȡ��ǰ�ĵ�ָ��
	ASSERT_VALID(pDoc);
	if (!pDoc)                           
		return;                          
	
	int cadObjCount = pDoc->m_cadObjArray.GetSize();              // ��ȡͼ�ζ�����Ŀ             
	for(int i = 0; i < cadObjCount; i++)                          // ȡ��ͼ�ζ��󲢻���
		((CCADGraphic *)pDoc->m_cadObjArray.GetAt(i))->Draw(pDC);
	
	list<CPoint>::iterator iPt; 

	for(iPt = pDoc->m_ptsCurve.begin(); iPt != pDoc->m_ptsCurve.end();)
	{
		pDC->MoveTo(*iPt);
		iPt++;
		if(iPt != pDoc->m_ptsCurve.end())		
			pDC->LineTo(*iPt);
	}
}

void CCADView::OnPaint()
{
	CPaintDC dc(this); // device context for painting
	// TODO: �ڴ˴�������Ϣ�����������
	// ��Ϊ��ͼ��Ϣ���� CScrollView::OnPaint()
	OnPrepareDC(&dc);
	OnDraw(&dc);
}

// CCADView ��ӡ

void CCADView::OnFilePrintPreview()
{
#ifndef SHARED_HANDLERS
	AFXPrintPreview(this);
#endif
}

BOOL CCADView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// Ĭ��׼��
	return DoPreparePrinting(pInfo);
}

void CCADView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: ���Ӷ���Ĵ�ӡǰ���еĳ�ʼ������
}

void CCADView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: ���Ӵ�ӡ����е���������
	
}

void CCADView::OnRButtonUp(UINT /* nFlags */, CPoint point)
{
	ClientToScreen(&point);
	OnContextMenu(this, point);
}

void CCADView::OnContextMenu(CWnd* /* pWnd */, CPoint point)
{
#ifndef SHARED_HANDLERS
	theApp.GetContextMenuManager()->ShowPopupMenu(IDR_POPUP_EDIT, point.x, point.y, this, TRUE);
#endif
}


// CCADView ���

#ifdef _DEBUG
void CCADView::AssertValid() const
{
	CScrollView::AssertValid();
}

void CCADView::Dump(CDumpContext& dc) const
{
	CScrollView::Dump(dc);
}

CCADDoc* CCADView::GetDocument() const // �ǵ��԰汾��������
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CCADDoc)));
	return (CCADDoc*)m_pDocument;
}
#endif //_DEBUG


// CCADView ��Ϣ��������

void CCADView::OnIdrClr()//������ɫ
{
	CColorDialog clrDlg;                           // ʵ����һ����ɫ�Ի���
	clrDlg.m_cc.Flags |= CC_RGBINIT | CC_FULLOPEN; // �������ݳ�Ա������
	clrDlg.m_cc.rgbResult = m_graClr;              // ��ȡ֮ǰ�û������ò����ڳ�ʼ����Ӧ����

	if(IDOK == clrDlg.DoModal())                   // �����öԻ��� ���û�ѡ�����ɫ�󱣴��û����õ���ɫ          
		m_graClr = clrDlg.m_cc.rgbResult;          // ������ɫ
} 

void CCADView::OnIdrSet()//��������
{
	CSettingDlg settingDlg;                        // ʵ����һ���������öԻ��� 
	settingDlg.m_uilineWidth = m_uilineWidth;      // ��ȡ֮ǰ�û���������ò���ʼ���Ի����е���Щ����
	settingDlg.m_ilineStyle = m_ilineStyle;
	
	if(IDOK == settingDlg.DoModal())               // ���û����ú����Ժ󱣴�
	{
		m_uilineWidth = settingDlg.m_uilineWidth;  // �����߿�
		m_ilineStyle = settingDlg.m_ilineStyle;    // ��������
	}
}

void CCADView::OnIdrDot()
{
	m_uidrawType = DOT;        // ���»�ͼ�������� �� ��ť�󽫻�ͼ��������Ϊ ��
}

void CCADView::OnIdrLine()
{
	m_uidrawType = LINE;      // ���»�ͼ�������� ֱ�� ��ť�󽫻�ͼ��������Ϊ ֱ��
}

void CCADView::OnIdrRect()
{
	m_uidrawType = RECTANGLE; // ���»�ͼ�������� ���� ��ť�󽫻�ͼ��������Ϊ ����
}

void CCADView::OnIdrEllipse()
{
	m_uidrawType = ELLIPSE;   // ���»�ͼ�������� ��Բ ��ť�󽫻�ͼ��������Ϊ ��Բ
}

void CCADView::OnIdrCircle()
{
	m_uidrawType = CIRCLE;    // ���»�ͼ�������� Բ ��ť�󽫻�ͼ��������Ϊ Բ
}

void CCADView::OnIdrTriangle()
{
	m_uidrawType = TRIANGLE; // ���»�ͼ�������� ֱ�������� ��ť�󽫻�ͼ��������Ϊ ֱ��������
}

void CCADView::OnIdrArc()   
{
	m_uidrawType = ARC;      // ���»�ͼ�������� ���� ��ť�󽫻�ͼ��������Ϊ ����
}

void CCADView::OnIdrPie()    
{
	m_uidrawType = PIE;      // ���»�ͼ�������� �� ��ť�󽫻�ͼ��������Ϊ ��
}

void CCADView::OnIdrRoundrect()
{
	m_uidrawType = RRECT;    // ���»�ͼ�������� Բ�Ǿ��� ��ť�󽫻�ͼ��������Ϊ Բ�Ǿ���
}

void CCADView::OnIdrCurve()
{
	m_uidrawType = CURVE;    // ���»�ͼ�������� ���� ��ť�󽫻�ͼ��������Ϊ ����
}


void CCADView::OnLButtonDown(UINT nFlags, CPoint point)
{
	m_ptFrom = point;   // �������
	m_ptTo = point;     // �����յ�

	if(m_uidrawType != CURVE)// �����ǻ���������
	{
		m_bTracking = true;  // ��ʼ׷��
	

		if(m_bCapEn)         // ��׽����������
			SetCapture();
		::SetCursor(::LoadCursor(NULL, IDC_CROSS));  // ����ʮ�ֹ��
	}
	else                     // ������������
	{
		m_bDrawing = true;
	}
	
	CScrollView::OnLButtonDown(nFlags, point);
}

void CCADView::OnLButtonUp(UINT nFlags, CPoint point)
{
	if(m_uidrawType == CURVE)
		m_bDrawing = false;         // ֹͣ������
	if(m_bTracking)                 // ������׷��״̬ ���������ſ���           
	{
		m_bTracking = false;        // ֹͣ׷��
		if(GetCapture() == this)    // ֹͣ��׽
			::ReleaseCapture();

	    CClientDC viewDC(this);                                                  // ��ȡ��ǰ��ͼ�ͻ���
		CPen pen(m_ilineStyle, m_uilineWidth, m_graClr);                         // ��������ʼ������
		viewDC.SelectObject(pen);                                                // ����ǰ����ѡ���豸������
		CBrush *pBrush = CBrush::FromHandle((HBRUSH)GetStockObject(NULL_BRUSH)); // ����͸����ˢ
		viewDC.SelectObject(pBrush);                                             // ����ǰ��ˢѡ���豸������

		CPoint circleCenter;                                                         // Բ��
		circleCenter.x = (float(m_ptFrom.x + point.x)) / 2;
		circleCenter.y = (float(m_ptFrom.y + point.y)) / 2;
		int m_iRadius = sqrt(double(point.y - m_ptFrom.y) * (point.y - m_ptFrom.y)   // �뾶
			                 + (point.x - m_ptFrom.x) * (point.x - m_ptFrom.x)) / 2;

		ShowMove(&viewDC, m_uidrawType, m_uilineWidth, m_ilineStyle, m_graClr, m_ptFrom, m_ptTo); // �ƶ��л�ͼ
		CCADDoc *pCCADDoc = GetDocument();                    // ��ȡ��ǰ�ĵ�ָ��

		switch(m_uidrawType)
		{
		case DOT:                               // .
			viewDC.SetPixel(point, m_graClr);
			break;
		case LINE:                              // --->
			viewDC.MoveTo(m_ptFrom);
			viewDC.LineTo(point);
			break;
		case RECTANGLE:                         // ��
			viewDC.Rectangle(CRect(m_ptFrom, point));
			break;
		case ELLIPSE:                           // 0
			viewDC.Ellipse(CRect(m_ptFrom, point));
			break;
		case CIRCLE:                            // O
			viewDC.Ellipse(circleCenter.x - m_iRadius, circleCenter.y - m_iRadius,
				           circleCenter.x + m_iRadius, circleCenter.y + m_iRadius);		
			break;
		case TRIANGLE:
			viewDC.MoveTo(m_ptFrom);            
			viewDC.LineTo(point.x, m_ptFrom.y); // --->
		    
			viewDC.MoveTo(m_ptFrom);            //.
			viewDC.LineTo(point);               // .
			                                    //  .
			viewDC.MoveTo(point.x, m_ptFrom.y); //   |
			viewDC.LineTo(point);               //   |
											    //   V
		    break;
		case ARC:                               // C
			viewDC.Arc(CRect(m_ptFrom, point), m_ptFrom, point);
			break;
		case PIE:                               // D
			viewDC.Pie(CRect(m_ptFrom, point), m_ptFrom, point);
			break;
		case RRECT:                                      
			viewDC.RoundRect(m_ptFrom.x, m_ptFrom.y,     // .-.
				             point.x, point.y,           //|   |
				             (point.x - m_ptFrom.x) / 2, //|   |
							 (point.y - m_ptFrom.y) / 2);// ._.
			break;
		case CURVE:
			/*if(!pCCADDoc->m_ptsCurve.empty())
				pCCADDoc->m_ptsCurve.pop_front();*/
			break;
		default:
			break;
		}
		CCADGraphic *pCCADGraphic = new CCADGraphic(m_uidrawType, 
			                                        m_ilineStyle, 
													m_uilineWidth, 
													m_graClr, 
													m_ptFrom, 
													point);   // ����ͼ�ζ���
		pCCADDoc->m_cadObjArray.Add(pCCADGraphic);            // ����ͼ�ζ���
	}
	CScrollView::OnLButtonUp(nFlags, point);
}


void CCADView::OnInitialUpdate()
{
	CScrollView::OnInitialUpdate();
	SetScrollSizes(MM_TEXT, CSize(1600, 1200));
}

void CCADView::OnMouseMove(UINT nFlags, CPoint point)
{

	CClientDC dc(this);                                                      // ��ȡ��ǰ��ͼ�ͻ��� ���븸�������
	CPen pen(m_ilineStyle, m_uilineWidth, m_graClr);                         // ��������ʼ������
	dc.SelectObject(pen);                                                    // ����ǰ����ѡ���豸������
	CBrush *pBrush = CBrush::FromHandle((HBRUSH)GetStockObject(NULL_BRUSH)); // ����͸����ˢ
	dc.SelectObject(pBrush);                                                 // ����ǰ��ˢѡ���豸������

	CCADDoc *pCCADDoc = GetDocument();                                       // ��ȡ��ǰ�ĵ�ָ��
	
	ShowGraInfo(m_uidrawType, m_ptFrom, m_ptTo);

	if(m_uidrawType != CURVE)
	{
		if(m_bTracking) // ������׷�ٵ���
		{                                           
     		ShowMove(&dc, m_uidrawType, m_uilineWidth, m_ilineStyle, m_graClr, m_ptFrom, m_ptTo); // �ƶ��л�ͼ
			ShowMove(&dc, m_uidrawType, m_uilineWidth, m_ilineStyle, m_graClr, m_ptFrom, point);   
			m_ptTo = point;
		}
	}
	else
	{
		if(m_bDrawing) // ���ڻ�����״̬
		{
			pCCADDoc->m_ptsCurve.push_back(m_ptFrom);
			dc.MoveTo(m_ptFrom); // �ƶ������
			dc.LineTo(point);    // ������
			m_ptFrom = point;    // �������
		}
	}
	CScrollView::OnMouseMove(nFlags, point);
}

void CCADView::ShowMove(CDC *pDC, 
	                    DRAW_TYPE uidrawType, 
						LINE_WIDTH uilineWidth, 
		                LINE_STYLE ilineStyle, 
						COLORREF graClr, 
			            CPoint ptFrom, 
						CPoint ptTo)
{
    int oldMode = pDC->SetROP2(R2_NOT);                     // ���û�ͼģʽΪ ����ԭ�ȵ�ͼ�� ������ԭ�ȵĻ�ͼģʽ
	CPen pen(m_ilineStyle, m_uilineWidth, graClr);          // ��������ʼ������
    pDC->SelectObject(pen);                                 // ����ǰ����ѡ���豸������
	CBrush *pBrush = CBrush::FromHandle((HBRUSH)GetStockObject(NULL_BRUSH)); // ����͸����ˢ
    pDC->SelectObject(pBrush);                                               // ����ǰ��ˢѡ���豸������

	CPoint circleCenter;                                    // Բ��
	circleCenter.x = (float(m_ptFrom.x + ptTo.x)) / 2;
	circleCenter.y = (float(m_ptFrom.y + ptTo.y)) / 2;
	int	m_iRadius = sqrt(double(ptTo.y - m_ptFrom.y)        // �뾶
			* (ptTo.y - m_ptFrom.y) + (ptTo.x - m_ptFrom.x)
			* (ptTo.x - m_ptFrom.x)) / 2;

	switch(m_uidrawType)
	{
	case DOT:                          
		break;
	case LINE:                         // --->
		pDC->MoveTo(ptFrom);
		pDC->LineTo(ptTo);
		break;
	case RECTANGLE:                    // ��  
		/*pDC->MoveTo(ptFrom);            
		pDC->LineTo(ptTo.x, ptFrom.y); // --->
		
		pDC->MoveTo(ptTo.x, ptFrom.y); //    |
		pDC->LineTo(ptTo);             //    |
		                               //    V
		pDC->MoveTo(ptTo);             // <--- 
		pDC->LineTo(ptFrom.x, ptTo.y); 

		pDC->MoveTo(ptFrom.x, ptTo.y); // ^
		pDC->LineTo(ptFrom);           // |
		                               // | 
		*/
		pDC->Rectangle(CRect(ptFrom, ptTo));
		break;                         
	case ELLIPSE:                             // 0
		pDC->Ellipse(CRect(ptFrom, ptTo));    
		break;                                
	case CIRCLE:                              // O      
        pDC->Ellipse(circleCenter.x - m_iRadius, circleCenter.y - m_iRadius, 
				     circleCenter.x + m_iRadius, circleCenter.y + m_iRadius);
		break;
	case TRIANGLE:
		pDC->MoveTo(ptFrom);            
		pDC->LineTo(ptTo.x, ptFrom.y); // --->
		
		pDC->MoveTo(ptFrom);           //.
		pDC->LineTo(ptTo);             // .
		                               //  .
		pDC->MoveTo(ptTo.x, ptFrom.y); //   |
		pDC->LineTo(ptTo);             //   |
		                               //   V
		break;
	case ARC:                          // C
		pDC->Arc(CRect(ptFrom, ptTo), ptFrom, ptTo);
		break;
	case PIE:                          // D
		pDC->Pie(CRect(ptFrom, ptTo), ptFrom, ptTo);
		break;
	case RRECT:
		pDC->RoundRect(ptFrom.x, ptFrom.y,       // .-.
			           ptTo.x, ptTo.y,           // | |
			           (ptTo.x - ptFrom.x) / 2,  // | |
					   (ptTo.y - ptFrom.y) / 2); // ._.
		break;
	case CURVE:
		break;
	default:
		break;
	}
	pDC->SetROP2(oldMode);       // �л�ԭ���Ļ�ͼģʽ
}

void CCADView::ShowGraInfo(DRAW_TYPE uidrawType, CPoint ptFrom, CPoint ptTo)
{
	CMainFrame *pCMainFrame = (CMainFrame *)AfxGetApp()->m_pMainWnd;
	CMFCStatusBar *pCStatusBar = &pCMainFrame->m_wndStatusBar;
	CString graInfo_str;
	CSize graInfo_sz;
	CClientDC dc(this);	
	int index = 0;

	switch(uidrawType)
	{
	case DOT:
		graInfo_str.Format(_T("Dot>>"));                            // ״̬����ʾ���� 
		graInfo_sz = dc.GetTextExtent(graInfo_str);		
		index = pCStatusBar->CommandToIndex(ID_GRA);
		pCStatusBar->SetPaneInfo(index, ID_GRA, SBPS_NORMAL, graInfo_sz.cx);
		pCStatusBar->SetPaneText(index, graInfo_str);

		graInfo_str.Format(_T("End(%d, %d)"), ptTo.x, ptTo.y);              // ״̬����ʾ�յ� 
		graInfo_sz = dc.GetTextExtent(graInfo_str);		
		index = pCStatusBar->CommandToIndex(ID_GRA_);
		pCStatusBar->SetPaneInfo(index, ID_GRA_, SBPS_NORMAL, graInfo_sz.cx);
		pCStatusBar->SetPaneText(index, graInfo_str);
		
		graInfo_str.Format(_T("::"));
		graInfo_sz = dc.GetTextExtent(graInfo_str);		
		index = pCStatusBar->CommandToIndex(ID_GRA__);
		pCStatusBar->SetPaneInfo(index, ID_GRA__, SBPS_NORMAL, graInfo_sz.cx);
		pCStatusBar->SetPaneText(index, graInfo_str);

		graInfo_str.Format(_T(":::"));
		graInfo_sz = dc.GetTextExtent(graInfo_str);		
		index = pCStatusBar->CommandToIndex(ID_GRA___);
		pCStatusBar->SetPaneInfo(index, ID_GRA___, SBPS_NORMAL, graInfo_sz.cx);
		pCStatusBar->SetPaneText(index, graInfo_str);

		break;  
	case LINE:
		graInfo_str.Format(_T("Line>>"));                            // ״̬����ʾ��ֱ�� 
		graInfo_sz = dc.GetTextExtent(graInfo_str);		
		index = pCStatusBar->CommandToIndex(ID_GRA);
		pCStatusBar->SetPaneInfo(index, ID_GRA, SBPS_NORMAL, graInfo_sz.cx);
		pCStatusBar->SetPaneText(index, graInfo_str);

		graInfo_str.Format(_T("From(%d, %d)"), ptFrom.x, ptFrom.y);         // ״̬����ʾ��� 
		graInfo_sz = dc.GetTextExtent(graInfo_str);
		index = pCStatusBar->CommandToIndex(ID_GRA_);
		pCStatusBar->SetPaneInfo(index, ID_GRA_, SBPS_NORMAL, graInfo_sz.cx);
		pCStatusBar->SetPaneText(index, graInfo_str);
		
		graInfo_str.Format(_T("To(%d, %d)"), ptTo.x, ptTo.y);               // ״̬����ʾ�յ� 
		graInfo_sz = dc.GetTextExtent(graInfo_str);
		index = pCStatusBar->CommandToIndex(ID_GRA__);
		pCStatusBar->SetPaneInfo(index, ID_GRA__, SBPS_NORMAL, graInfo_sz.cx);
		pCStatusBar->SetPaneText(index, graInfo_str);

		graInfo_str.Format(_T("Lenth(%d)"), int(sqrt(double((ptTo.x - ptFrom.x) * (ptTo.x - ptFrom.x) 
			                                      + (ptTo.y - ptFrom.y) * (ptTo.y - ptFrom.y)))));
		graInfo_sz = dc.GetTextExtent(graInfo_str);		
		index = pCStatusBar->CommandToIndex(ID_GRA___);
		pCStatusBar->SetPaneInfo(index, ID_GRA___, SBPS_NORMAL, graInfo_sz.cx);
		pCStatusBar->SetPaneText(index, graInfo_str);
		
		break;
	case RECTANGLE:
		graInfo_str.Format(_T("Rectangle>>"));                            // ״̬����ʾ������ 
		graInfo_sz = dc.GetTextExtent(graInfo_str);		
		index = pCStatusBar->CommandToIndex(ID_GRA);
		pCStatusBar->SetPaneInfo(index, ID_GRA, SBPS_NORMAL, graInfo_sz.cx);
		pCStatusBar->SetPaneText(index, graInfo_str);

		graInfo_str.Format(_T("Width(%d)"), int(fabs(double(ptTo.x - ptTo.y))));  // ״̬����ʾ����
		graInfo_sz = dc.GetTextExtent(graInfo_str);
		index = pCStatusBar->CommandToIndex(ID_GRA_);
		pCStatusBar->SetPaneInfo(index, ID_GRA_, SBPS_NORMAL, graInfo_sz.cx);
		pCStatusBar->SetPaneText(index, graInfo_str);
		
		graInfo_str.Format(_T("Height(%d)"), int(fabs(double(ptTo.y - ptFrom.y)))); // ״̬����ʾ�߶�
		graInfo_sz = dc.GetTextExtent(graInfo_str);
		index = pCStatusBar->CommandToIndex(ID_GRA__);
		pCStatusBar->SetPaneInfo(index, ID_GRA__, SBPS_NORMAL, graInfo_sz.cx);
		pCStatusBar->SetPaneText(index, graInfo_str);

		graInfo_str.Format(_T("Center(%d, %d)"), int(fabs(double((ptTo.x - ptTo.y) / 2))),  // ״̬����ʾ����
			                                     int(fabs(double((ptTo.y - ptFrom.y) / 2)))); 
		graInfo_sz = dc.GetTextExtent(graInfo_str);		
		index = pCStatusBar->CommandToIndex(ID_GRA___);
		pCStatusBar->SetPaneInfo(index, ID_GRA___, SBPS_NORMAL, graInfo_sz.cx);
		pCStatusBar->SetPaneText(index, graInfo_str);
		
		break;
	case ELLIPSE:
		graInfo_str.Format(_T("Ellipse>>"));                            // ״̬����ʾ����Բ 
		graInfo_sz = dc.GetTextExtent(graInfo_str);		
		index = pCStatusBar->CommandToIndex(ID_GRA);
		pCStatusBar->SetPaneInfo(index, ID_GRA, SBPS_NORMAL, graInfo_sz.cx);
		pCStatusBar->SetPaneText(index, graInfo_str);

		graInfo_str.Format(_T("Long Axis(%d)"), int(fabs(double(ptTo.x - ptFrom.x))));  // ״̬����ʾ����
		graInfo_sz = dc.GetTextExtent(graInfo_str);
		index = pCStatusBar->CommandToIndex(ID_GRA_);
		pCStatusBar->SetPaneInfo(index, ID_GRA_, SBPS_NORMAL, graInfo_sz.cx);
		pCStatusBar->SetPaneText(index, graInfo_str);
		
		graInfo_str.Format(_T("Short Axis(%d)"), int(fabs(double(ptTo.y - ptFrom.y)))); // ״̬����ʾ����
		graInfo_sz = dc.GetTextExtent(graInfo_str);
		index = pCStatusBar->CommandToIndex(ID_GRA__);
		pCStatusBar->SetPaneInfo(index, ID_GRA__, SBPS_NORMAL, graInfo_sz.cx);
		pCStatusBar->SetPaneText(index, graInfo_str);

		graInfo_str.Format(_T("Center(%d, %d)"), int(fabs(double((ptTo.x - ptTo.y) / 2))),  // ״̬����ʾ����
			                                     int(fabs(double((ptTo.y - ptFrom.y) / 2))));
		graInfo_sz = dc.GetTextExtent(graInfo_str);		
		index = pCStatusBar->CommandToIndex(ID_GRA___);
		pCStatusBar->SetPaneInfo(index, ID_GRA___, SBPS_NORMAL, graInfo_sz.cx);
		pCStatusBar->SetPaneText(index, graInfo_str);

		break;
	case CIRCLE:
		graInfo_str.Format(_T("Circle>>"));                            // ״̬����ʾ��Բ 
		graInfo_sz = dc.GetTextExtent(graInfo_str);		
		index = pCStatusBar->CommandToIndex(ID_GRA);
		pCStatusBar->SetPaneInfo(index, ID_GRA, SBPS_NORMAL, graInfo_sz.cx);
		pCStatusBar->SetPaneText(index, graInfo_str);

		graInfo_str.Format(_T("Radius(%d)"), int(sqrt(double((ptTo.x - ptFrom.x) * (ptTo.x - ptFrom.x)  // ״̬����ʾ�뾶
			                                       + (ptTo.y - ptFrom.y) * (ptTo.y - ptFrom.y)))) / 2);
		graInfo_sz = dc.GetTextExtent(graInfo_str);
		index = pCStatusBar->CommandToIndex(ID_GRA_);
		pCStatusBar->SetPaneInfo(index, ID_GRA_, SBPS_NORMAL, graInfo_sz.cx);
		pCStatusBar->SetPaneText(index, graInfo_str);
		
		graInfo_str.Format(_T("Center(%d, %d)"), int(fabs(double((ptTo.x - ptTo.y) / 2))),  // ״̬����ʾԲ��
			                                     int(fabs(double((ptTo.y - ptFrom.y) / 2))));
		graInfo_sz = dc.GetTextExtent(graInfo_str);
		index = pCStatusBar->CommandToIndex(ID_GRA__);
		pCStatusBar->SetPaneInfo(index, ID_GRA__, SBPS_NORMAL, graInfo_sz.cx);
		pCStatusBar->SetPaneText(index, graInfo_str);

		graInfo_str.Format(_T(":::"));
		graInfo_sz = dc.GetTextExtent(graInfo_str);		
		index = pCStatusBar->CommandToIndex(ID_GRA___);
		pCStatusBar->SetPaneInfo(index, ID_GRA___, SBPS_NORMAL, graInfo_sz.cx);
		pCStatusBar->SetPaneText(index, graInfo_str);

		break;
	case TRIANGLE:
		graInfo_str.Format(_T("Right Triangle>>"));                            // ״̬����ʾ��ֱ�������� 
		graInfo_sz = dc.GetTextExtent(graInfo_str);		
		index = pCStatusBar->CommandToIndex(ID_GRA);
		pCStatusBar->SetPaneInfo(index, ID_GRA, SBPS_NORMAL, graInfo_sz.cx);
		pCStatusBar->SetPaneText(index, graInfo_str);

		graInfo_str.Format(_T("Top(%d, %d)"), ptFrom.x, ptTo.y);      // ״̬����ʾ����
		graInfo_sz = dc.GetTextExtent(graInfo_str);
		index = pCStatusBar->CommandToIndex(ID_GRA_);
		pCStatusBar->SetPaneInfo(index, ID_GRA_, SBPS_NORMAL, graInfo_sz.cx);
		pCStatusBar->SetPaneText(index, graInfo_str);
		
		graInfo_str.Format(_T("From(%d, %d)"), ptFrom.x, ptFrom.y);   // ״̬����ʾ�����
		graInfo_sz = dc.GetTextExtent(graInfo_str);
		index = pCStatusBar->CommandToIndex(ID_GRA__);
		pCStatusBar->SetPaneInfo(index, ID_GRA__, SBPS_NORMAL, graInfo_sz.cx);
		pCStatusBar->SetPaneText(index, graInfo_str);

		graInfo_str.Format(_T("To(%d, %d)"), ptTo.x, ptTo.y);
		graInfo_sz = dc.GetTextExtent(graInfo_str);		
		index = pCStatusBar->CommandToIndex(ID_GRA___);
		pCStatusBar->SetPaneInfo(index, ID_GRA___, SBPS_NORMAL, graInfo_sz.cx);
		pCStatusBar->SetPaneText(index, graInfo_str);

		break;
	case ARC:
		graInfo_str.Format(_T("Arc>>"));                            // ״̬����ʾ������ 
		graInfo_sz = dc.GetTextExtent(graInfo_str);		
		index = pCStatusBar->CommandToIndex(ID_GRA);
		pCStatusBar->SetPaneInfo(index, ID_GRA, SBPS_NORMAL, graInfo_sz.cx);
		pCStatusBar->SetPaneText(index, graInfo_str);

		graInfo_str.Format(_T("From(%d, %d)"), ptFrom.x, ptFrom.y); // ״̬����ʾ���
		graInfo_sz = dc.GetTextExtent(graInfo_str);
		index = pCStatusBar->CommandToIndex(ID_GRA_);
		pCStatusBar->SetPaneInfo(index, ID_GRA_, SBPS_NORMAL, graInfo_sz.cx);
		pCStatusBar->SetPaneText(index, graInfo_str);
		
		graInfo_str.Format(_T("To(%d, %d)"), ptTo.x, ptTo.y);  // ״̬����ʾ�յ�
		graInfo_sz = dc.GetTextExtent(graInfo_str);
		index = pCStatusBar->CommandToIndex(ID_GRA__);
		pCStatusBar->SetPaneInfo(index, ID_GRA__, SBPS_NORMAL, graInfo_sz.cx);
		pCStatusBar->SetPaneText(index, graInfo_str);

		graInfo_str.Format(_T(":::"));
		graInfo_sz = dc.GetTextExtent(graInfo_str);		
		index = pCStatusBar->CommandToIndex(ID_GRA___);
		pCStatusBar->SetPaneInfo(index, ID_GRA___, SBPS_NORMAL, graInfo_sz.cx);
		pCStatusBar->SetPaneText(index, graInfo_str);

		break;
	case PIE:
		graInfo_str.Format(_T("Pie>>"));                            // ״̬����ʾ���� 
		graInfo_sz = dc.GetTextExtent(graInfo_str);		
		index = pCStatusBar->CommandToIndex(ID_GRA);
		pCStatusBar->SetPaneInfo(index, ID_GRA, SBPS_NORMAL, graInfo_sz.cx);
		pCStatusBar->SetPaneText(index, graInfo_str);

		graInfo_str.Format(_T("From(%d, %d)"), ptFrom.x, ptFrom.y); // ״̬����ʾ���
		graInfo_sz = dc.GetTextExtent(graInfo_str);
		index = pCStatusBar->CommandToIndex(ID_GRA_);
		pCStatusBar->SetPaneInfo(index, ID_GRA_, SBPS_NORMAL, graInfo_sz.cx);
		pCStatusBar->SetPaneText(index, graInfo_str);
		
		graInfo_str.Format(_T("To(%d, %d)"), ptTo.x, ptTo.y);  // ״̬����ʾ�յ�
		graInfo_sz = dc.GetTextExtent(graInfo_str);
		index = pCStatusBar->CommandToIndex(ID_GRA__);
		pCStatusBar->SetPaneInfo(index, ID_GRA__, SBPS_NORMAL, graInfo_sz.cx);
		pCStatusBar->SetPaneText(index, graInfo_str);

		graInfo_str.Format(_T(":::"));
		graInfo_sz = dc.GetTextExtent(graInfo_str);		
		index = pCStatusBar->CommandToIndex(ID_GRA___);
		pCStatusBar->SetPaneInfo(index, ID_GRA___, SBPS_NORMAL, graInfo_sz.cx);
		pCStatusBar->SetPaneText(index, graInfo_str);

		break;
	case RRECT:
		graInfo_str.Format(_T("Round Rectangle>>"));           // ״̬����ʾ��Բ�Ǿ��� 
		graInfo_sz = dc.GetTextExtent(graInfo_str);		
		index = pCStatusBar->CommandToIndex(ID_GRA);
		pCStatusBar->SetPaneInfo(index, ID_GRA, SBPS_NORMAL, graInfo_sz.cx);
		pCStatusBar->SetPaneText(index, graInfo_str);

		graInfo_str.Format(_T("Long Axis(%d)"), int(fabs(double(ptTo.x - ptFrom.x)))); // ״̬����ʾ����
		graInfo_sz = dc.GetTextExtent(graInfo_str);
		index = pCStatusBar->CommandToIndex(ID_GRA_);
		pCStatusBar->SetPaneInfo(index, ID_GRA_, SBPS_NORMAL, graInfo_sz.cx);
		pCStatusBar->SetPaneText(index, graInfo_str);
		
		graInfo_str.Format(_T("Short Axis(%d)"), int(fabs(double(ptTo.y - ptFrom.y)))); // ״̬����ʾ����
		graInfo_sz = dc.GetTextExtent(graInfo_str);
		index = pCStatusBar->CommandToIndex(ID_GRA__);
		pCStatusBar->SetPaneInfo(index, ID_GRA__, SBPS_NORMAL, graInfo_sz.cx);
		pCStatusBar->SetPaneText(index, graInfo_str);

		graInfo_str.Format(_T("Center(%d, %d)"), int(fabs(double((ptTo.x - ptTo.y) / 2))), // ״̬����ʾ����
			                                     int(fabs(double((ptTo.y - ptFrom.y) / 2))));
		graInfo_sz = dc.GetTextExtent(graInfo_str);		
		index = pCStatusBar->CommandToIndex(ID_GRA___);
		pCStatusBar->SetPaneInfo(index, ID_GRA___, SBPS_NORMAL, graInfo_sz.cx);
		pCStatusBar->SetPaneText(index, graInfo_str);

		break;
	case CURVE:
		graInfo_str.Format(_T("Curve>>"));                            // ״̬����ʾ������
		graInfo_sz = dc.GetTextExtent(graInfo_str);		
		index = pCStatusBar->CommandToIndex(ID_GRA);
		pCStatusBar->SetPaneInfo(index, ID_GRA, SBPS_NORMAL, graInfo_sz.cx);
		pCStatusBar->SetPaneText(index, graInfo_str);

		graInfo_str.Format(_T("From(%d, %d)"), ptTo.x, ptTo.y); // ״̬����ʾ���
		graInfo_sz = dc.GetTextExtent(graInfo_str);
		index = pCStatusBar->CommandToIndex(ID_GRA_);
		pCStatusBar->SetPaneInfo(index, ID_GRA_, SBPS_NORMAL, graInfo_sz.cx);
		pCStatusBar->SetPaneText(index, graInfo_str);
		
		graInfo_str.Format(_T("To(%d, %d)"), ptFrom.x, ptFrom.y); // ״̬����ʾ�յ�
		graInfo_sz = dc.GetTextExtent(graInfo_str);
		index = pCStatusBar->CommandToIndex(ID_GRA__);
		pCStatusBar->SetPaneInfo(index, ID_GRA__, SBPS_NORMAL, graInfo_sz.cx);
		pCStatusBar->SetPaneText(index, graInfo_str);

		graInfo_str.Format(_T(":::"));
		graInfo_sz = dc.GetTextExtent(graInfo_str);		
		index = pCStatusBar->CommandToIndex(ID_GRA___);
		pCStatusBar->SetPaneInfo(index, ID_GRA___, SBPS_NORMAL, graInfo_sz.cx);
		pCStatusBar->SetPaneText(index, graInfo_str);

		break;
	default:
		break;
	}
}

