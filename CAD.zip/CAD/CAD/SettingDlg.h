#pragma once

#include "datatype_and_constants.h"

// CSettingDlg �Ի���

class CSettingDlg : public CDialog
{
	DECLARE_DYNAMIC(CSettingDlg)

public:
	CSettingDlg(CWnd* pParent = NULL);
	virtual ~CSettingDlg();

	enum { IDD = IDD_SET_DLG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);
	
	afx_msg void OnChangeEditLineWidth();
	afx_msg void OnClickedReal();
	afx_msg void OnVir();
	afx_msg void OnDot();
	
	DECLARE_MESSAGE_MAP()

public:
	LINE_WIDTH  m_uilineWidth;
	LINE_STYLE  m_ilineStyle;

};
